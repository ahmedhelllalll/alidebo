<?php

namespace App\Http\Controllers;

use App\Models\ProfileSection;
use Illuminate\Http\Request;

class ProfileSectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProfileSection $profileSection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProfileSection $profileSection)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ProfileSection $profileSection)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProfileSection $profileSection)
    {
        //
    }
}
