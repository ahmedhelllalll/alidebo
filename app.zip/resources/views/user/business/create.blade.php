@extends('layouts.dashboard.app')

@section('content')
<main class="flex flex-col lg:flex-row min-h-screen bg-slate-50 dark:bg-[#09090b]">
    <section class="w-full lg:w-[45%] flex flex-col justify-center px-8 py-12 lg:px-16 bg-white dark:bg-zinc-950 border-l border-slate-100 dark:border-zinc-900 order-2 lg:order-1 relative z-10">
        <div class="w-full max-w-md mx-auto fade-in">

            <a href="{{ route('dashboard') }}" class="inline-flex items-center gap-2 text-slate-400 hover:text-primary font-bold text-sm mb-10 transition-colors group">
                <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"></path>
                </svg>
                العودة للوحة التحكم
            </a>

            <header class="mb-10 text-right">
                <h1 class="text-3xl font-[900] text-slate-900 dark:text-white mb-3">ابدأ رحلتك الآن 🚀</h1>
                <p class="text-slate-500 dark:text-zinc-400 font-medium">املأ البيانات الأساسية لإنشاء ملف شركتك الاحترافي.</p>
            </header>

            <form id="create-business-form" method="POST" action="{{ route('business.store') }}" enctype="multipart/form-data" class="space-y-6">
                @csrf

                <div class="space-y-2">
                    <label class="text-sm font-bold text-slate-700 dark:text-zinc-300 px-1 block text-right">اسم الشركة أو النشاط</label>
                    <input type="text" name="name" required value="{{ old('name') }}" placeholder="مثال: ديبو ديزاين"
                        class="w-full px-5 py-4 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl focus:ring-2 focus:ring-primary outline-none transition-all dark:text-white font-medium text-right shadow-sm" />
                    @error('name') <p class="text-red-500 text-xs mt-1 text-right">{{ $message }}</p> @enderror
                </div>

                <div class="space-y-2">
                    <label class="text-sm font-bold text-slate-700 dark:text-zinc-300 px-1 block text-right">وصف مختصر (SEO)</label>
                    <textarea name="meta_description" rows="4" placeholder="ما الذي يميز شركتك؟"
                        class="w-full px-5 py-4 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl focus:ring-2 focus:ring-primary outline-none transition-all dark:text-white font-medium text-right shadow-sm resize-none">{{ old('meta_description') }}</textarea>
                    @error('meta_description') <p class="text-red-500 text-xs mt-1 text-right">{{ $message }}</p> @enderror
                </div>

                <div class="space-y-2">
                    <label class="text-sm font-bold text-slate-700 dark:text-zinc-300 px-1 block text-right">شعار الشركة (اختياري)</label>
                    <input type="file" name="logo" accept="image/*"
                        class="w-full px-5 py-3 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-2xl outline-none dark:text-white text-right shadow-sm file:ml-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-orange-600" />
                </div>

                <button type="submit" id="submit-btn" class="w-full flex items-center justify-center bg-primary text-white py-5 rounded-2xl font-black text-lg shadow-[0_10px_30px_rgba(244,80,24,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300">
                    <span id="btn-text">إنشاء الملف التجاري</span>
                    <div id="btn-loader" class="loader hidden"></div>
                </button>
            </form>
        </div>
    </section>

    <section class="w-full lg:w-[55%] p-10 lg:p-24 flex flex-col items-center justify-center bg-slate-50 dark:bg-[#0c0c0e] relative overflow-hidden text-center order-1 lg:order-2">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px]"></div>

        <div class="relative z-10 w-full max-w-2xl mx-auto">
            <div class="fade-in">
                <h2 class="text-4xl lg:text-6xl font-semibold tracking-tight text-slate-800 dark:text-zinc-100 leading-tight mb-6">
                    صمم هويتك...
                    <span class="block mt-4 pb-4 font-[900] glow-text drop-shadow-[0_0_15px_rgba(244,80,24,0.3)]">
                        بلمسة من الإبداع.
                    </span>
                </h2>
                <p class="text-lg font-medium text-slate-400 dark:text-zinc-500 max-w-md mx-auto mb-16 italic">
                    "الاسم والوصف هما أول ما يراه عميلك، اجعلهما لا يُنسيان."
                </p>
            </div>

            <div class="group relative inline-block w-full max-w-sm">
                <div class="absolute -inset-1 bg-gradient-to-r from-primary to-orange-400 rounded-[2.5rem] blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                <div class="relative bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 p-8 rounded-[2.5rem] shadow-2xl">
                    <div class="w-16 h-16 bg-primary/10 rounded-2xl mx-auto mb-6 flex items-center justify-center text-3xl">🏢</div>
                    <div class="space-y-3">
                        <div class="w-3/4 h-3 bg-slate-100 dark:bg-zinc-800 rounded-full mx-auto"></div>
                        <div class="w-1/2 h-3 bg-slate-50 dark:bg-zinc-800/50 rounded-full mx-auto"></div>
                    </div>
                    <div class="mt-8 pt-6 border-t border-slate-50 dark:border-zinc-800/50">
                        <div class="text-[10px] font-black uppercase tracking-widest text-primary">AliDebo Enterprise</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
    .fade-in {
        animation: fadeIn 0.8s ease-out forwards;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(15px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .glow-text {
        background: linear-gradient(to left, #f45018, #fb923c, #f45018);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: shine 3s linear infinite;
    }

    @keyframes shine {
        to {
            background-position: 200% center;
        }
    }

    .loader {
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top: 3px solid #fff;
        width: 24px;
        height: 24px;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }
</style>

<script>
    const form = document.getElementById('create-business-form');
    const btn = document.getElementById('submit-btn');
    const loader = document.getElementById('btn-loader');
    const text = document.getElementById('btn-text');

    form.addEventListener('submit', function() {
        btn.disabled = true;
        text.classList.add('hidden');
        loader.classList.remove('hidden');
        btn.classList.add('opacity-80');
    });
</script>
@endsection