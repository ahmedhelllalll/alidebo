{{-- resources/views/dashboard/index.blade.php --}}
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم | AliDebo</title>
    
    {{-- Favicon --}}
    <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">

    {{-- Fonts --}}
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    {{-- Tailwind --}}
    <script src="https://cdn.tailwindcss.com"></script>
    
    {{-- Alpine.js للتفاعل الخفيف --}}
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fff2ed',
                            100: '#ffe1d4',
                            200: '#ffc4a8',
                            300: '#ff9f71',
                            400: '#ff7640',
                            500: '#f45018',
                            600: '#e03c0c',
                            700: '#b32b09',
                            800: '#8f210b',
                            900: '#751d0d',
                            DEFAULT: '#f45018'
                        },
                        surface: {
                            light: '#ffffff',
                            dark: '#0a0a0c'
                        }
                    },
                    fontFamily: {
                        cairo: ['Cairo', 'sans-serif']
                    },
                    animation: {
                        'gradient': 'gradient 8s linear infinite',
                        'float': 'float 6s ease-in-out infinite',
                        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'shimmer': 'shimmer 2s linear infinite',
                    },
                    keyframes: {
                        gradient: {
                            '0%, 100%': {
                                'background-size': '200% 200%',
                                'background-position': 'left center'
                            },
                            '50%': {
                                'background-size': '200% 200%',
                                'background-position': 'right center'
                            }
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-20px)' }
                        },
                        shimmer: {
                            '0%': { backgroundPosition: '-1000px 0' },
                            '100%': { backgroundPosition: '1000px 0' }
                        }
                    },
                    backgroundImage: {
                        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
                    }
                }
            }
        }

        // Theme detection
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        ::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 20px;
        }

        .dark ::-webkit-scrollbar-thumb {
            background: #2d2d35;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #cbd5e1;
        }

        .dark ::-webkit-scrollbar-thumb:hover {
            background: #40404a;
        }

        /* Glassmorphism */
        .glass {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .dark .glass {
            background: rgba(10, 10, 12, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.03);
        }

        .glass-strong {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.8);
        }

        .dark .glass-strong {
            background: rgba(18, 18, 22, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.03);
        }

        /* Card hover effects */
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px -15px rgba(244, 80, 24, 0.2);
        }

        /* Gradient text */
        .gradient-text {
            background: linear-gradient(135deg, #f45018 0%, #ff8a5c 50%, #f45018 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradient 8s linear infinite;
        }

        /* Loading shimmer */
        .shimmer {
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            background-size: 1000px 100%;
            animation: shimmer 2s infinite;
        }

        /* RTL specific */
        .rtl-flip {
            transform: scaleX(-1);
        }

        /* Mobile menu animation */
        .mobile-menu-enter {
            opacity: 0;
            transform: scale(0.95) translateY(-10px);
        }
        .mobile-menu-enter-active {
            opacity: 1;
            transform: scale(1) translateY(0);
            transition: opacity 0.2s, transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .mobile-menu-exit {
            opacity: 1;
            transform: scale(1) translateY(0);
        }
        .mobile-menu-exit-active {
            opacity: 0;
            transform: scale(0.95) translateY(-10px);
            transition: opacity 0.2s, transform 0.2s;
        }

        /* Stats cards */
        .stat-card {
            background: linear-gradient(135deg, rgba(244, 80, 24, 0.1) 0%, rgba(244, 80, 24, 0.02) 100%);
            border: 1px solid rgba(244, 80, 24, 0.1);
        }

        .dark .stat-card {
            background: linear-gradient(135deg, rgba(244, 80, 24, 0.15) 0%, rgba(244, 80, 24, 0.05) 100%);
            border: 1px solid rgba(244, 80, 24, 0.1);
        }

        /* Empty state animation */
        @keyframes float-slow {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            33% { transform: translateY(-30px) rotate(2deg); }
            66% { transform: translateY(-15px) rotate(-2deg); }
        }
        .float-slow {
            animation: float-slow 8s ease-in-out infinite;
        }
    </style>
</head>

<body class="bg-[#f8fafc] dark:bg-[#030304] text-slate-900 dark:text-zinc-100 min-h-screen overflow-x-hidden" 
      x-data="{ 
        mobileMenuOpen: false,
        notificationsOpen: false,
        stats: {
            views: '12.5k',
            profiles: 0,
            pending: 0
        }
      }"
      @keydown.escape.window="mobileMenuOpen = false; notificationsOpen = false">

    {{-- Floating Background Elements --}}
    <div class="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div class="absolute top-20 left-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div class="absolute bottom-20 right-1/4 w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-[120px] animate-pulse-slow" style="animation-delay: 2s;"></div>
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/3 rounded-full blur-[150px]"></div>
    </div>

    {{-- Main Layout --}}
    <div class="relative z-10 flex min-h-screen">
        
        {{-- Sidebar (Desktop) --}}
        <aside class="hidden lg:flex lg:w-80 xl:w-96 flex-col fixed h-screen glass-strong border-l border-slate-200/50 dark:border-zinc-800/50">
            {{-- Brand --}}
            <div class="p-8 pb-6">
                <div class="flex items-center gap-3 group cursor-pointer" onclick="window.location='/'">
                    <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-orange-400 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-primary/30 group-hover:scale-110 transition-transform">
                        AD
                    </div>
                    <div>
                        <span class="text-2xl font-black tracking-tighter block leading-tight">alidebo</span>
                        <span class="text-[10px] font-bold text-primary uppercase tracking-widest">business hub</span>
                    </div>
                </div>
            </div>

            {{-- User Profile --}}
            <div class="px-6 mb-6">
                <div class="stat-card rounded-2xl p-4">
                    <div class="flex items-center gap-3">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name) }}&background=f45018&color=fff&bold=true&size=128" 
                             class="w-12 h-12 rounded-xl border-2 border-white dark:border-zinc-800 shadow-lg" 
                             alt="{{ Auth::user()->name }}">
                        <div class="flex-1">
                            <h3 class="font-black text-sm">{{ Auth::user()->name }}</h3>
                            <p class="text-xs text-slate-500 dark:text-zinc-400 font-medium">{{ Auth::user()->email }}</p>
                        </div>
                        <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    </div>
                </div>
            </div>

            {{-- Navigation --}}
            <nav class="flex-1 px-6 space-y-1">
                @php
                    $menuItems = [
                        ['icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6', 'label' => 'الرئيسية', 'active' => true],
                        ['icon' => 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4', 'label' => 'شركاتي'],
                        ['icon' => 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z', 'label' => 'الإحصائيات'],
                        ['icon' => 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9', 'label' => 'التنبيهات', 'badge' => 3],
                        ['icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z', 'label' => 'الإعدادات'],
                    ];
                @endphp

                @foreach($menuItems as $item)
                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 {{ $item['active'] ?? false ? 'bg-primary/10 text-primary font-bold' : 'text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800/60 font-medium' }}">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $item['icon'] }}"/>
                    </svg>
                    <span class="flex-1 text-sm">{{ $item['label'] }}</span>
                    @if(isset($item['badge']))
                        <span class="bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded-full">{{ $item['badge'] }}</span>
                    @endif
                </a>
                @endforeach
            </nav>

            {{-- Logout --}}
            <div class="p-6 mt-auto border-t border-slate-200/50 dark:border-zinc-800/50">
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all font-bold text-sm">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                        </svg>
                        تسجيل الخروج
                    </button>
                </form>
            </div>
        </aside>

        {{-- Main Content --}}
        <main class="flex-1 lg:mr-80 xl:mr-96 min-h-screen relative">
            
            {{-- Mobile Header --}}
            <header class="lg:hidden glass sticky top-0 z-50 px-4 py-3 border-b border-slate-200/50 dark:border-zinc-800/50">
                <div class="flex items-center justify-between">
                    <button @click="mobileMenuOpen = !mobileMenuOpen" class="p-2 -mr-2">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                    
                    <div class="flex items-center gap-2">
                        <span class="text-xl font-black">alidebo</span>
                    </div>

                    <button @click="notificationsOpen = !notificationsOpen" class="p-2 relative">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        <span class="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full animate-pulse"></span>
                    </button>
                </div>

                {{-- Mobile Menu Overlay --}}
                <div x-show="mobileMenuOpen" 
                     x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0"
                     x-transition:enter-end="opacity-100"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100"
                     x-transition:leave-end="opacity-0"
                     class="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
                     @click="mobileMenuOpen = false">
                </div>

                {{-- Mobile Menu Panel --}}
                <div x-show="mobileMenuOpen"
                     x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0 -translate-x-full"
                     x-transition:enter-end="opacity-100 translate-x-0"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100 translate-x-0"
                     x-transition:leave-end="opacity-0 -translate-x-full"
                     class="fixed inset-y-0 right-0 w-72 glass-strong z-50 shadow-2xl overflow-y-auto">
                    
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-8">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white font-black">AD</div>
                                <span class="text-xl font-black">alidebo</span>
                            </div>
                            <button @click="mobileMenuOpen = false" class="p-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>

                        <div class="space-y-6">
                            <div class="flex items-center gap-3 p-4 stat-card rounded-2xl">
                                <img src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name) }}&background=f45018&color=fff" class="w-12 h-12 rounded-xl" alt="">
                                <div>
                                    <h3 class="font-black">{{ Auth::user()->name }}</h3>
                                    <p class="text-xs text-slate-500">{{ Auth::user()->email }}</p>
                                </div>
                            </div>

                            <nav class="space-y-2">
                                @foreach($menuItems as $item)
                                <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-slate-100 dark:hover:bg-zinc-800 transition-all">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $item['icon'] }}"/>
                                    </svg>
                                    <span class="flex-1">{{ $item['label'] }}</span>
                                    @if(isset($item['badge']))
                                        <span class="bg-primary text-white text-xs px-2 py-0.5 rounded-full">{{ $item['badge'] }}</span>
                                    @endif
                                </a>
                                @endforeach
                            </nav>

                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="flex items-center gap-3 w-full px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-all">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                                    </svg>
                                    تسجيل الخروج
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            {{-- Main Content Area --}}
            <div class="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
                
                {{-- Header with Date & Search --}}
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                    <div>
                        <h1 class="text-3xl md:text-4xl font-black mb-2">
                            مرحباً، <span class="gradient-text">{{ Auth::user()->name }}</span>
                        </h1>
                        <p class="text-slate-500 dark:text-zinc-400 font-medium flex items-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                            {{ now()->locale('ar')->translatedFormat('l، d F Y') }}
                        </p>
                    </div>
                    
                    <div class="flex items-center gap-3">
                        <div class="relative">
                            <input type="text" 
                                   placeholder="ابحث عن شركة..." 
                                   class="w-full md:w-64 px-5 py-3 bg-slate-100/50 dark:bg-zinc-800/40 border border-slate-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all">
                            <svg class="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                            </svg>
                        </div>
                        
                        <button class="hidden md:flex items-center gap-2 px-4 py-3 bg-primary text-white rounded-xl font-bold text-sm hover:bg-primary-dark transition-all shadow-lg shadow-primary/30">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                            </svg>
                            إنشاء جديد
                        </button>
                    </div>
                </div>

                @if($isEmpty)
                    {{-- EMPTY STATE: User has no businesses --}}
                    <div class="min-h-[calc(100vh-300px)] flex items-center justify-center">
                        <div class="max-w-3xl w-full text-center space-y-8">
                            
                            {{-- Floating Illustrations --}}
                            <div class="relative h-64 mb-12">
                                <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64">
                                    <div class="absolute inset-0 bg-gradient-radial from-primary/20 to-transparent rounded-full animate-pulse-slow"></div>
                                    <div class="absolute inset-0 flex items-center justify-center float-slow">
                                        <div class="w-40 h-40 bg-gradient-to-br from-primary to-orange-400 rounded-[3rem] shadow-2xl shadow-primary/30 flex items-center justify-center">
                                            <svg class="w-20 h-20 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- Content --}}
                            <div class="space-y-6">
                                <h2 class="text-4xl md:text-5xl font-black">
                                    ابدأ رحلتك الرقمية
                                    <span class="block text-primary text-2xl md:text-3xl mt-3">مع AliDebo</span>
                                </h2>
                                
                                <p class="text-slate-500 dark:text-zinc-400 text-lg max-w-xl mx-auto font-medium leading-relaxed">
                                    أنشئ ملفاً تعريفياً احترافياً لشركتك في دقائق، واجذب آلاف العملاء مع قوالبنا الذكية ودعمنا التسويقي المتميز.
                                </p>

                                {{-- Features Grid --}}
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mt-8">
                                    <div class="stat-card rounded-2xl p-4 text-center">
                                        <div class="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-2">
                                            <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"/>
                                            </svg>
                                        </div>
                                        <h3 class="font-black text-sm">قوالب احترافية</h3>
                                    </div>
                                    <div class="stat-card rounded-2xl p-4 text-center">
                                        <div class="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-2">
                                            <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"/>
                                            </svg>
                                        </div>
                                        <h3 class="font-black text-sm">تحليلات دقيقة</h3>
                                    </div>
                                    <div class="stat-card rounded-2xl p-4 text-center">
                                        <div class="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-2">
                                            <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                            </svg>
                                        </div>
                                        <h3 class="font-black text-sm">ظهور في البحث</h3>
                                    </div>
                                </div>

                                {{-- CTA Button --}}
                                <div class="pt-8">
                                    <a href="{{ route('business.create') }}" 
                                       class="inline-flex items-center gap-3 px-8 py-5 bg-gradient-to-r from-primary to-orange-500 text-white rounded-2xl font-black text-lg shadow-2xl shadow-primary/40 hover:shadow-primary/60 hover:scale-105 transition-all duration-300 group">
                                        <svg class="w-6 h-6 group-hover:rotate-90 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                                        </svg>
                                        أنشئ بروفايل شركتك الآن
                                    </a>
                                    <p class="text-sm text-slate-400 mt-4">لا تحتاج لبطاقة ائتمان • 5 دقائق فقط</p>
                                </div>
                            </div>
                        </div>
                    </div>

                @else
                    {{-- NORMAL STATE: User has businesses --}}
                    
                    {{-- Stats Cards --}}
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                        <div class="stat-card rounded-2xl p-6 card-hover">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-slate-500 dark:text-zinc-400">إجمالي الشركات</span>
                                <div class="w-8 h-8 bg-primary/10 rounded-xl flex items-center justify-center">
                                    <svg class="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                                    </svg>
                                </div>
                            </div>
                            <p class="text-3xl font-black">{{ $businesses->count() }}</p>
                            <p class="text-xs text-slate-400 mt-1">+2 عن الشهر الماضي</p>
                        </div>

                        <div class="stat-card rounded-2xl p-6 card-hover">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-slate-500 dark:text-zinc-400">قيد المراجعة</span>
                                <div class="w-8 h-8 bg-yellow-500/10 rounded-xl flex items-center justify-center">
                                    <svg class="w-4 h-4 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                    </svg>
                                </div>
                            </div>
                            <p class="text-3xl font-black">{{ $businesses->where('status', 'pending')->count() }}</p>
                            <p class="text-xs text-slate-400 mt-1">في انتظار الموافقة</p>
                        </div>

                        <div class="stat-card rounded-2xl p-6 card-hover">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-slate-500 dark:text-zinc-400">الزيارات</span>
                                <div class="w-8 h-8 bg-emerald-500/10 rounded-xl flex items-center justify-center">
                                    <svg class="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                    </svg>
                                </div>
                            </div>
                            <p class="text-3xl font-black">12.5k</p>
                            <p class="text-xs text-slate-400 mt-1">+18.2% هذا الأسبوع</p>
                        </div>

                        <div class="stat-card rounded-2xl p-6 card-hover">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-bold text-slate-500 dark:text-zinc-400">نسبة الظهور</span>
                                <div class="w-8 h-8 bg-purple-500/10 rounded-xl flex items-center justify-center">
                                    <svg class="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                                    </svg>
                                </div>
                            </div>
                            <p class="text-3xl font-black">89%</p>
                            <p class="text-xs text-slate-400 mt-1">+5% عن الأمس</p>
                        </div>
                    </div>

                    {{-- Quick Actions --}}
                    <div class="flex items-center gap-3 mb-8 overflow-x-auto pb-2 scrollbar-thin">
                        <a href="{{ route('business.create') }}" 
                           class="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-xl font-bold text-sm whitespace-nowrap shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            إضافة شركة جديدة
                        </a>
                        <button class="flex items-center gap-2 px-6 py-3 bg-slate-100 dark:bg-zinc-800 rounded-xl font-bold text-sm whitespace-nowrap hover:bg-slate-200 dark:hover:bg-zinc-700 transition-all">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                            </svg>
                            تصدير التقرير
                        </button>
                    </div>

                    {{-- Businesses Grid --}}
                    <div class="space-y-6">
                        <div class="flex items-center justify-between">
                            <h2 class="text-xl font-black flex items-center gap-2">
                                <span>شركاتي</span>
                                <span class="bg-slate-200 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 text-xs px-2 py-1 rounded-full">{{ $businesses->count() }}</span>
                            </h2>
                            <a href="#" class="text-primary text-sm font-bold hover:underline">عرض الكل</a>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            @foreach($businesses as $business)
                            <div class="group relative bg-white dark:bg-zinc-900/50 rounded-3xl border border-slate-200 dark:border-zinc-800 overflow-hidden card-hover hover:border-primary/30">
                                {{-- Status Badge --}}
                                <div class="absolute top-4 right-4 z-10">
                                    @if($business->status === 'approved')
                                        <span class="bg-emerald-500/10 text-emerald-500 text-xs font-bold px-3 py-1 rounded-full border border-emerald-500/20">منشور</span>
                                    @elseif($business->status === 'pending')
                                        <span class="bg-yellow-500/10 text-yellow-500 text-xs font-bold px-3 py-1 rounded-full border border-yellow-500/20">قيد المراجعة</span>
                                    @elseif($business->status === 'rejected')
                                        <span class="bg-red-500/10 text-red-500 text-xs font-bold px-3 py-1 rounded-full border border-red-500/20">مرفوض</span>
                                    @else
                                        <span class="bg-slate-500/10 text-slate-500 text-xs font-bold px-3 py-1 rounded-full border border-slate-500/20">مسودة</span>
                                    @endif
                                </div>

                                {{-- Cover Image --}}
                                <div class="h-32 bg-gradient-to-br from-primary/20 to-orange-400/20 relative">
                                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                </div>

                                {{-- Logo --}}
                                <div class="relative px-6">
                                    <div class="absolute -top-8 right-6 w-16 h-16 rounded-2xl bg-white dark:bg-zinc-900 border-4 border-white dark:border-zinc-900 shadow-xl overflow-hidden">
                                        <img src="https://ui-avatars.com/api/?name={{ urlencode($business->name) }}&background=f45018&color=fff&bold=true&size=128" 
                                             class="w-full h-full object-cover" 
                                             alt="{{ $business->name }}">
                                    </div>
                                </div>

                                {{-- Content --}}
                                <div class="p-6 pt-10">
                                    <h3 class="font-black text-lg mb-1">{{ $business->name }}</h3>
                                    <p class="text-xs text-slate-500 dark:text-zinc-400 font-medium mb-4 flex items-center gap-1">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>
                                        </svg>
                                        {{ $business->slug }}
                                    </p>

                                    {{-- Stats --}}
                                    <div class="flex items-center gap-4 text-xs text-slate-500 dark:text-zinc-400 mb-4">
                                        <span class="flex items-center gap-1">
                                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                            </svg>
                                            1.2k
                                        </span>
                                        <span class="flex items-center gap-1">
                                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                                            </svg>
                                            3
                                        </span>
                                    </div>

                                    {{-- Actions --}}
                                    <div class="flex items-center gap-2">
                                        <a href="{{ route('business.edit', $business) }}" class="flex-1 text-center py-2.5 bg-slate-100 dark:bg-zinc-800 rounded-xl text-sm font-bold hover:bg-slate-200 dark:hover:bg-zinc-700 transition-all">
                                            تعديل
                                        </a>
                                        <a href="/{{ $business->slug }}" target="_blank" class="flex-1 text-center py-2.5 bg-primary text-white rounded-xl text-sm font-bold hover:bg-primary-dark transition-all shadow-lg shadow-primary/30">
                                            عرض
                                        </a>
                                        <button class="p-2.5 bg-slate-100 dark:bg-zinc-800 rounded-xl hover:bg-slate-200 dark:hover:bg-zinc-700 transition-all">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"/>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>

                    {{-- Recent Activity --}}
                    <div class="mt-12 bg-white dark:bg-zinc-900/30 rounded-3xl border border-slate-200 dark:border-zinc-800 p-6">
                        <h3 class="font-black text-lg mb-6">آخر النشاطات</h3>
                        <div class="space-y-4">
                            @foreach(range(1,4) as $i)
                            <div class="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-all">
                                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    </svg>
                                </div>
                                <div class="flex-1">
                                    <p class="font-bold text-sm">تمت مشاهدة ملف <span class="text-primary">متجر الأمل</span></p>
                                    <p class="text-xs text-slate-500">منذ 5 دقائق • الرياض</p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            </div>
        </main>
    </div>

    {{-- Floating Action Button (Mobile) --}}
    @if(!$isEmpty)
    <div class="lg:hidden fixed bottom-6 left-6 z-40">
        <a href="{{ route('business.create') }}" 
           class="w-14 h-14 bg-gradient-to-r from-primary to-orange-500 rounded-2xl shadow-2xl shadow-primary/40 flex items-center justify-center text-white hover:scale-110 transition-transform">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
        </a>
    </div>
    @endif

    <script>
        // حفظ حالة الثيم
        function toggleTheme() {
            const html = document.documentElement;
            html.classList.toggle('dark');
            localStorage.setItem('theme', html.classList.contains('dark') ? 'dark' : 'light');
        }

        // منع التمرير عند فتح الموبايل مينو
        document.addEventListener('alpine:init', () => {
            Alpine.effect(() => {
                if (Alpine.store('mobileMenuOpen')) {
                    document.body.style.overflow = 'hidden';
                } else {
                    document.body.style.overflow = 'auto';
                }
            });
        });
    </script>
</body>
</html>